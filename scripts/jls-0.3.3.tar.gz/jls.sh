#!/usr/bin/env sh
exec /usr/bin/java -jar /usr/share/java/jls/jls.jar "$@"
